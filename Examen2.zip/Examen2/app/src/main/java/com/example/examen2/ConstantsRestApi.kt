package com.example.examen2

class ConstantsRestApi
{
    companion object {
        const val URL_BASE = "https://jsonplaceholder.typicode.com/posts"
        const val POSTS ="/posts"
    }

}