package com.example.examen2

data class User(val userId: String, val id: String, val title: String, val body: String)