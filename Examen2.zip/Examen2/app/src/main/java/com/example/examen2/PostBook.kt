package com.example.examen2

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "book_table")
class PostBook (@ColumnInfo(name ="title") var tittle: String, @ColumnInfo(name = "body") var body: String) {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Long = 0
}
