package com.example.examen2

import androidx.room.ColumnInfo


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "book_table")
class Book(@ColumnInfo(name = "title") var title: String) {
    val body: String
        get() {
            TODO()
        }

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Long = 0
}
